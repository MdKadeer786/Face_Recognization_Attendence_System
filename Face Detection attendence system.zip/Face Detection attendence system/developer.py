from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2

class developer:
    def __init__(self,root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("Face detection System")

        # title 
        title_lbl = Label(self.root,text="DEVELOPER",font=("times new roman",35,"bold"),bg="silver",fg="green")
        title_lbl.place(x=0,y=0,width=1530,height=55)

    #first image
        img = Image.open(r"college_images\developer.jpg")
        img = img.resize((1530,750),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img)
        f_lbl = Label(self.root,image=self.photoimg)
        f_lbl.place(x=0,y=55,width=1530,height=750)

         # MAIN FRAME
        main_frame= Frame(f_lbl,bd=2,background="lightgreen")
        main_frame.place(x=1000,y=0,width=520,height=600)

        img_top = Image.open(r"college_images\face.jpg")
        img_top = img_top.resize((200,200),Image.ANTIALIAS) 
        self.photoimg1=ImageTk.PhotoImage(img_top)

        f_lbl2 = Label(main_frame,image=self.photoimg1,)
        f_lbl2.place(x=300,y=0,width=200,height=200)

        developer_label= Label(main_frame,text="Hi ,I am Abdul Quadir",font=("times new roman",20,"bold"),bg="lightgreen",fg="red")
        developer_label.place(x=0,y=5)

        developer_labe2= Label(main_frame,text="I am a web developer ",font=("times new roman",20,"bold"),bg="lightgreen",fg="red")
        developer_labe2.place(x = 0,y=40)






if __name__ == "__main__":
   root = Tk()
   obj = developer(root)
   root.mainloop()