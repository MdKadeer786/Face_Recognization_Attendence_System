img_top = Image.open(r"college_images\face.jpg")
        # img_top = img_top.resize((200,200),Image.ANTIALIAS)
        # self.photoimg=ImageTk.PhotoImage(img_top)

        # f_lbl = Label(main_frame,image=self.photoimg)
        # f_lbl.place(x=0,y=0,width=200,height=200)