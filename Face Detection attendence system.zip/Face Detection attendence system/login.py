from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from main import Face_Detection_System
import mysql.connector
import cv2


def main():
    root=Tk()
    app = Login(root)
    root.mainloop()
    


class Login:
    def __init__(self,root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("Login Page")

    
        # img = Image.open(r"D:\Face Detection attendence system\Login_Pages\image\login1.jpg
        # img = img.resize((1550,800),Image.ANTIALIAS)
        # self.photoimg=ImageTk.PhotoImage(img)
        self.bg= ImageTk.PhotoImage(file=r"D:\Face Detection attendence system\Login_Pages\image\img1.jpg")
        f_lbl = Label(self.root,image=self.bg)
        f_lbl.place(x=0,y=0,relheight=1,relwidth=1)

        Frame1 = Frame(self.root,bg="black")
        Frame1.place(x=610,y=170,width=340,height=450)

        img1 = Image.open(r"D:\Face Detection attendence system\Login_Pages\image\login2.webp")
        img1 = img1.resize((100,100),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img1)
        f_lbl = Label(self.root,image=self.photoimg,bg="black")
        f_lbl.place(x=730,y=175,height=100,width=100)


        get_str = Label(Frame1,text="Get Started",font=("times new roman",20,"bold"),fg="white",bg="black")
        get_str.place(x=100,y=100)

        # laels

        username = lbl=Label(Frame1,text="Username:",font=("times new roman",15,"bold"),fg="white",bg="black")
        username.place(x=70,y=155)

        self.textuser= Entry(Frame1,font=("times new roman",15,"bold"))
        self.textuser.place(x=40,y=180,width=270)

        password = lbl=Label(Frame1,text="Password:",font=("times new roman",15,"bold"),fg="white",bg="black")
        password.place(x=70,y=225)

        self.textpassword= Entry(Frame1,font=("times new roman",15,"bold"))
        self.textpassword.place(x=40,y=250,width=270)

        #=============Icon Image============
        img2 = Image.open(r"D:\Face Detection attendence system\Login_Pages\image\login2.webp")
        img2 = img2.resize((25,25),Image.ANTIALIAS)
        self.photoimg1=ImageTk.PhotoImage(img2)
        f_lbl = Label(self.root,image=self.photoimg1,bg="black",borderwidth=0)
        f_lbl.place(x=650,y=323,height=25,width=25)

        img3 = Image.open(r"D:\Face Detection attendence system\Login_Pages\image\login2.webp")
        img3 = img3.resize((25,25),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img3)
        f_lbl = Label(self.root,image=self.photoimg2,bg="black",borderwidth=0)
        f_lbl.place(x=650,y=395,height=25,width=25)


        # login btm
        login_btn = Button(Frame1,text="Login",command=self.login,font=("times new roman",15,"bold"),bd=3,relief=RIDGE,bg="red",fg="white",activebackground="white",activeforeground="red")
        login_btn.place(x=110,y=300,height=35,width=120)

        # register btm
        register_btn = Button(Frame1,text="New User Register",command=self.register_window,font=("times new roman",12,"bold"),bd=3,borderwidth=0,bg="black",fg="white",activebackground="white",activeforeground="red")
        register_btn.place(x=20,y=350,height=35,width=160)

        # forget btm
        forget_btn = Button(Frame1,text="Forget Password",command=self.forget_password,font=("times new roman",12,"bold"),bd=3,borderwidth=0,bg="black",fg="white",activebackground="white",activeforeground="red")
        forget_btn.place(x=15,y=380,height=35,width=160)

        #============= function  ==============

    def login(self):
        if self.textuser.get()=="" or self.textpassword.get()=="":
            messagebox.showerror("error","all field required")
        
        elif self.textuser.get()=="abdul48" and self.textpassword.get()=="abdul123@":
            messagebox.showinfo("Success","welcome to my Attendence System")
        else:
            # messagebox.showerror("Invalid","Invalid Username and Password")
            conn = mysql.connector.connect(host = "localhost",username = "root",password = "Mdkadeer@1",database= "face_detection")
            my_cursor = conn.cursor()
            my_cursor.execute("select * from register where email=%s and password=%s",(
                self.textuser.get(),
                self.textpassword.get()
            ))
            row = my_cursor.fetchone()
            #print row
            if row == None:
                messagebox.showerror("error","invalid Username and password")
            else:
                open_main = messagebox.askyesno("YesNo","Access only admin")
                if open_main>0:
                    self.new_window=Toplevel(self.root)
                    self.app=Face_Detection_System(self.new_window)
                else:
                    if not open_main:
                        return
            conn.commit()
            conn.close()

    #================= reset passwoed btn function =============
    def reset_password(self):
        if self.seq_q_combo.get()=="Select":
            messagebox.showerror("error","Select security Question",parent=self.root2)
        elif self.seq_ans.get()=="":
            messagebox.showerror("error","Please enter the answer",parent=self.root2)
        elif self.new_password.get() =="":
            messagebox.showerror("error","Please enter the new password",parent=self.root2)
        else:
            conn = mysql.connector.connect(host = "localhost",username = "root",password = "Mdkadeer@1",database= "face_detection")
            my_cursor = conn.cursor()
            query = ("select * from register where email=%s and securityQ=%s and securityA=%s")
            value = (self.textuser.get(),self.seq_q_combo.get(),self.seq_ans.get(),)

            my_cursor.execute(query,value)
            row = my_cursor.fetchone()
            if row == None:
                messagebox.showerror("error","Please enter correct answer",parent=self.root2)
            else:
                query = ("update register set password=%s where email=%s")
                value = (self.new_password.get(),self.textuser.get(),)
                my_cursor.execute(query,value)

                conn.commit()
                conn.close()

                messagebox.showinfo("info","Your password has reset, please login new password",parent=self.root2)
                self.root2.destroy()






    #================== forget password window====================

    def forget_password(self):
        if self.textuser.get()=="":
            messagebox.showerror("error","Please enter te Email to reset password")
        else:
            conn = mysql.connector.connect(host = "localhost",username = "root",password = "Mdkadeer@1",database= "face_detection")
            my_cursor = conn.cursor()
            quary = ("select * from register where email=%s")
            value = (self.textuser.get(),)
            my_cursor.execute(quary,value)
            row = my_cursor.fetchone()
            #print(row)
            if row == None:
                messagebox.showerror("error","please enter the valid user name")
            else:
                conn.close()
                self.root2 = Toplevel()
                self.root2.title("Forget Password")
                self.root2.geometry("340x450+610+170")

                l = Label(self.root2,text="Fogrget Password",font=("times new roman",20,"bold"),fg="red",bg="white")
                l.place(x=0,y=10,relwidth=1)

                sec_q_label= Label(self.root2,text="Select Security Question",font=("times new roman",15,"bold"),bg="white")
                sec_q_label.place(x=50,y=80)

                self.seq_q_combo= ttk.Combobox(self.root2,font=("times new roman",12,"bold"),state="readonly")
                self.seq_q_combo.place(x=50,y=110,width=250)
                self.seq_q_combo["value"]= ("Select","Your burth place","your childhood name","Your best friend","Your father name")
                self.seq_q_combo.current(0)
                

                
                seq_ans= Label(self.root2,text="Security Answer",font=("times new roman",15,"bold"),bg="white")
                seq_ans.place(x=50,y=150)
                self.seq_ans = ttk.Entry(self.root2,width=20,font=("times new roman",15,"bold"))
                self.seq_ans.place(x=50,y=180,width=250)

                new_password= Label(self.root2,text="New Password",font=("times new roman",15,"bold"),bg="white",fg="black")
                new_password.place(x=50,y=220)

                self.new_password = ttk.Entry(self.root2,width=20,font=("times new roman",15,"bold"))
                self.new_password.place(x=50,y=250,width=250)

                btn = Button(self.root2,text="Reset",command=self.reset_password,font=("times new roman",15,"bold"),fg="white",bg="green")
                btn.place(x=100,y=290)




        

            

#==================== register codes====================
    def register_window(self):
        self.new_window = Toplevel(self.root)
        self.app = register( self.new_window)
        self.new_window.grab_set()


class register:
    def __init__(self,root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("Login Page")

        # ============ variable==============
        self.var_fname = StringVar()
        self.var_lname = StringVar()
        self.var_contact = StringVar()
        self.var_email = StringVar()
        self.var_securityQ = StringVar()
        self.var_securityA = StringVar()
        self.var_password = StringVar()
        self.var_confpassword = StringVar()


        self.bg= ImageTk.PhotoImage(file=r"D:\Face Detection attendence system\Login_Pages\image\img1.jpg")
        f_lbl = Label(self.root,image=self.bg)
        f_lbl.place(x=0,y=0,relheight=1,relwidth=1)

        # self.bg1= ImageTk.PhotoImage(file=r"D:\Face Detection attendence system\Login_Pages\image\reg.jpg")
        # ledt_lbl = Label(self.root,image=self.bg1)
        # ledt_lbl.place(x=50,y=100,height=550,width=470)

        img2 = Image.open(r"D:\Face Detection attendence system\Login_Pages\image\reg1.webp")
        img2 = img2.resize((550,470),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img2)
        f_lbl1 = Label(self.root,image=self.photoimg,bg="black",borderwidth=0)
        f_lbl1.place(x=50,y=100,height=550,width=470)
        #main frame
        Frame1 = Frame(self.root,bg="white")
        Frame1.place(x=520,y=100,width=800,height=550)


        refister_lbl=Label(Frame1,text="REGISTER HERE",font=("times new roman",20,"bold"),fg="green",bg="white")
        refister_lbl.place(x=20,y=20)

        #=========== lebel and entry============
        # row 1===============
        f_name_label= Label(Frame1,text="First Name",font=("times new roman",15,"bold"),bg="white")
        f_name_label.place(x=50,y=100)
        f_name_entry = ttk.Entry(Frame1,width=20,textvariable=self.var_fname,font=("times new roman",15,"bold"))
        f_name_entry.place(x=50,y=130,width=250)
        
        l_name_label= Label(Frame1,text="Last Name",font=("times new roman",15,"bold"),bg="white")
        l_name_label.place(x=370,y=100)
        l_name_entry = ttk.Entry(Frame1,width=20,textvariable=self.var_lname,font=("times new roman",15,"bold"))
        l_name_entry.place(x=370,y=130,width=250)

        # row 2===============
        f_name_label= Label(Frame1,text="Contact No.",font=("times new roman",15,"bold"),bg="white")
        f_name_label.place(x=50,y=170)
        f_name_entry = ttk.Entry(Frame1,width=20,textvariable=self.var_contact,font=("times new roman",15,"bold"))
        f_name_entry.place(x=50,y=200,width=250)
        
        l_name_label= Label(Frame1,text="Email",font=("times new roman",15,"bold"),bg="white")
        l_name_label.place(x=370,y=170)
        l_name_entry = ttk.Entry(Frame1,width=20,textvariable=self.var_email,font=("times new roman",15,"bold"))
        l_name_entry.place(x=370,y=200,width=250)

        # row 3===============
        sec_q_label= Label(Frame1,text="Select Security Question",font=("times new roman",15,"bold"),bg="white")
        sec_q_label.place(x=50,y=240)

        seq_q_combo= ttk.Combobox(Frame1,textvariable=self.var_securityQ,font=("times new roman",12,"bold"),state="readonly")
        seq_q_combo.place(x=50,y=270,width=250)
        seq_q_combo["value"]= ("Select","Your burth place","your childhood name","Your best friend","Your father name")
        seq_q_combo.current(0)
        

        
        ans_name_label= Label(Frame1,text="Security Answer",font=("times new roman",15,"bold"),bg="white")
        ans_name_label.place(x=370,y=240)
        ans_name_entry = ttk.Entry(Frame1,width=20,textvariable=self.var_securityA,font=("times new roman",15,"bold"))
        ans_name_entry.place(x=370,y=270,width=250)

         # row 4 ===============
        f_name_label= Label(Frame1,text="Password",font=("times new roman",15,"bold"),bg="white")
        f_name_label.place(x=50,y=310)
        f_name_entry = ttk.Entry(Frame1,width=20,textvariable=self.var_password,font=("times new roman",15,"bold"))
        f_name_entry.place(x=50,y=340,width=250)
        
        l_name_label= Label(Frame1,text="Confirm Password",font=("times new roman",15,"bold"),bg="white")
        l_name_label.place(x=370,y=310)
        l_name_entry = ttk.Entry(Frame1,width=20,textvariable=self.var_confpassword,font=("times new roman",15,"bold"))
        l_name_entry.place(x=370,y=340,width=250)

        #==============check button=========
        self.var_check=IntVar()
        checkbutton = Checkbutton(Frame1,text = "I Agree the Term and Condition",variable=self.var_check,font=("times new roman",13,"bold"),onvalue =1,offvalue = 0)
        checkbutton.place(x=50,y=380)

        # REGISTER NAW button
        img3 = Image.open(r"D:\Face Detection attendence system\Login_Pages\image\regnaw.jfif")
        img3 = img3.resize((200,55),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(img3)
        b1 = Button(Frame1,image=self.photoimg4,command=self.reg_data,borderwidth=0,cursor="hand2",bg="white")
        b1.place(x=50,y=450,width=200)

        # login naaw btn
        img4 = Image.open(r"D:\Face Detection attendence system\Login_Pages\image\loginnaw.jfif")
        img4 = img4.resize((200,50),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img4)
        b2 = Button(Frame1,image=self.photoimg2,borderwidth=0,cursor="hand2",command=self.return_login,font=("times new roman",15,"bold"),fg="white")
        b2.place(x=350,y=450,width=200)

    # ============= function ================
    def reg_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_securityQ.get()=="select":
            messagebox.showerror("error","all field are required",parent = self.root)
        elif self.var_password.get()!=self.var_confpassword.get():
            messagebox.showerror("Error","Password and confirm password must be same",parent = self.root)
        elif self.var_check.get()==0:
            messagebox.showerror("Error","Please agree your term and condition",parent = self.root)
        else:
            conn = mysql.connector.connect(host = "localhost",username = "root",password = "Mdkadeer@1",database= "face_detection")
            my_cursor = conn.cursor()
            quary = ("select * from register where email=%s")
            value = (self.var_email.get(),)
            my_cursor.execute(quary,value)
            row = my_cursor.fetchone()
            if row!=None:
                messagebox.showerror("error","Ueser already exist,please try amother email",parent = self.root)
            else:
                my_cursor.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s)",(
                                                                                    self.var_fname.get(),
                                                                                    self.var_lname.get(),
                                                                                    self.var_contact.get(),
                                                                                    self.var_email.get(),
                                                                                    self.var_securityQ.get(),
                                                                                    self.var_securityA.get(),
                                                                                    self.var_password.get(),
                                                                                    
                                                                                
                                                                                                    ))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success","Register Successfully",parent = self.root)

    def return_login(self):
         self.root.destroy()


if __name__ == "__main__":
    main()